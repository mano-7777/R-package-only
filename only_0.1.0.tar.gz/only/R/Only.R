#'Only Package
#'
#'Contains one function for separating the hour from the datetime column.
#'
#'@docType package
#'
#'@author Mano R \email{manoramu459@gmail.com}
#'
#'@name Only
#'NULL
